

export const Bio = {

    name : "Atharva Pawar",
    roles: [
        "FullStack Developer",
        "Programmer",
    ],

    description : 
    "I am a motivated and versatile individual, always eager to take on new challenges. With a passion for learning I am dedicated to delivering high-quality results. With a positive attitude and a growth mindset, I am ready to make a meaningful contribution and achieve great things.",
  github: "https://github.com/atharvapawar16",
  resume:"https://in.docworkspace.com/d/sIOqzs_NqmJbpsAY",
  twitter:"https://x.com/AtharvaPaw77364?t=cMNpLBAO6gveeGDWoRrW2g&s=09",
  linkedin: "https://www.linkedin.com/in/atharvapawar",
  Email : "atharvapawar1610@gmail.com",
 
};

export const skills =
[
    {
  title: "Frontend",
  skills : [
    {
        Name : "React",
        image  : "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9Ii0xMS41IC0xMC4yMzE3NCAyMyAyMC40NjM0OCI+CiAgPHRpdGxlPlJlYWN0IExvZ288L3RpdGxlPgogIDxjaXJjbGUgY3g9IjAiIGN5PSIwIiByPSIyLjA1IiBmaWxsPSIjNjFkYWZiIi8+CiAgPGcgc3Ryb2tlPSIjNjFkYWZiIiBzdHJva2Utd2lkdGg9IjEiIGZpbGw9Im5vbmUiPgogICAgPGVsbGlwc2Ugcng9IjExIiByeT0iNC4yIi8+CiAgICA8ZWxsaXBzZSByeD0iMTEiIHJ5PSI0LjIiIHRyYW5zZm9ybT0icm90YXRlKDYwKSIvPgogICAgPGVsbGlwc2Ugcng9IjExIiByeT0iNC4yIiB0cmFuc2Zvcm09InJvdGF0ZSgxMjApIi8+CiAgPC9nPgo8L3N2Zz4K", 
    },

    {
        Name : "Html",
        image  :"https://www.w3.org/html/logo/badge/html5-badge-h-solo.png",  
    },

    {
        Name : "CSS",
        image  : "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d5/CSS3_logo_and_wordmark.svg/1452px-CSS3_logo_and_wordmark.svg.png",   
    },

    {
        Name : "JavaScript",
        image  : "https://upload.wikimedia.org/wikipedia/commons/thumb/6/6a/JavaScript-logo.png/800px-JavaScript-logo.png", 
    },
    
  ],
},

{
    title: "Backend",
    skills: [
        {
            Name :"Java",
            image:  "https://raw.githubusercontent.com/devicons/devicon/master/icons/java/java-original.svg", 

        },
        {
            Name :"C++",
            image:"https://raw.githubusercontent.com/devicons/devicon/6910f0503efdd315c8f9b858234310c06e04d9c0/icons/cplusplus/cplusplus-original.svg", 

        },
        {
            Name :".NetMVC",
            image:"https://raw.githubusercontent.com/devicons/devicon/6910f0503efdd315c8f9b858234310c06e04d9c0/icons/dot-net/dot-net-plain-wordmark.svg", 

        },
        {
            Name :"MySql",
            image:"https://raw.githubusercontent.com/devicons/devicon/6910f0503efdd315c8f9b858234310c06e04d9c0/icons/mysql/mysql-plain-wordmark.svg", 

        },
        {
            Name :"MongoDB",
            image:"https://raw.githubusercontent.com/devicons/devicon/6910f0503efdd315c8f9b858234310c06e04d9c0/icons/mongodb/mongodb-plain-wordmark.svg", 

        },

    ],
},
{
    title : "Others",
    skills : [
        {
            Name: "SpringBoot",
            image: "https://raw.githubusercontent.com/devicons/devicon/6910f0503efdd315c8f9b858234310c06e04d9c0/icons/spring/spring-original-wordmark.svg",
        },

        {
            Name: "Hibernate",
            image:"https://raw.githubusercontent.com/devicons/devicon/6910f0503efdd315c8f9b858234310c06e04d9c0/icons/hibernate/hibernate-plain-wordmark.svg",
        },

        {
            Name: "Github",
            image:"https://github.githubassets.com/images/modules/logos_page/GitHub-Mark.png",
        },

        {
            Name: "Docker",
            image: "https://raw.githubusercontent.com/devicons/devicon/master/icons/docker/docker-original-wordmark.svg",
        },

        {
            Name: "IntelligeIdea",
            image:"https://raw.githubusercontent.com/devicons/devicon/6910f0503efdd315c8f9b858234310c06e04d9c0/icons/intellij/intellij-plain.svg",
        },

        {
            Name: "VsCode",
            image:"https://raw.githubusercontent.com/devicons/devicon/6910f0503efdd315c8f9b858234310c06e04d9c0/icons/vscode/vscode-original-wordmark.svg",
        },  
        
        {
            Name : "Postman",
            image :  "https://raw.githubusercontent.com/devicons/devicon/6910f0503efdd315c8f9b858234310c06e04d9c0/icons/postman/postman-original-wordmark.svg",
        }

    ]

}

];

export const education =[
    {
        id : 0 ,
        Degree : "Post Graduation Diploma In Advance Computing",
        College :"CDAC-ACTS",
        Grade : "72%",
        description:
        "I have recently completed a postgraduate diploma in Advanced Computing at CDAC-ACTS, Pune. During my studies, I have undertaken courses in Data Structures, Algorithms, Object-Oriented Programming, Database Management Systems, Operating Systems, and others.",
    },

    {
        id : 1 ,
        Degree : "Bachelor Of Engineering",
        College :"AISSMS COE",
        Grade : "8.10 CGPA",
        description:"I have completed a Bachelor's degree in Production Engineering at AISSMS COE, Pune."
    }
]

export const projects = [

    {
    id: 9,
    title: "Trip Planner",
    date: "Jan 2024 - feb 2024",
    description:
    "The trip planner website aims to make planning trips easier and more enjoyable by providing a comprehensive platform to create personalized itineraries, find activities, book accommodations, and access travel information .",
    
    technologies: [
      "Html",
      "Css",
      "JavaScript",
      "React",
      "Java",
      "Springboot",
      "Sql",  
    ],
    category: "web app",
},

{
    id: 10,
    title: "Employee Management System",
    date: "1 feb 2024 - 17 feb 2024",
    description:
    "The Employment Management System is a streamlined solution using React for the frontend and Spring Boot for the backend. With a user-friendly interface powered by React, users can easily manage employee information. Spring Boot implements CRUD methods, allowing for efficient Create, Read, Update, and Delete operations on employee records. This combination ensures a responsive and secure system for effective employment management",
    
    technologies: [
      "Html",
      "Css",
      "JavaScript",
      "React",
      "Java",
      "Springboot",
      "Sql",  
    ],
   
}
];
export const TimeLineData = [
    { year: 2018, text: "Started my journey" },
    { year: 2018, text: "started my Graduation" },
    { year: 2022, text: "Completed my graduation as a Production Engineer" },
    { year: 2023, text: "Started my post graduation diploma in advance computing from CDAC Pune in the journey of cdac i learn technologies in the front end i learn html,css,javascript , react & in the backend i learn java , c++ , asp.net , Sql " },
    { year: 2024, text: "Completed my post graduation diploma with first class " },
];
