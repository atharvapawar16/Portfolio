const express = require('express');
const app = express();

const port = process.env.port || 3000;

app.set('view engine', 'ejs');
app.use(express.static('public'));
app.use(express.json());
app.use(express.urlencoded({extended : true}));



// routes
app.get('/',(req,res)=>{
    res.render('index');
})

app.get('/about', (req , res)=>{
    res.render('render', {about:true});
})